# This folder hosts code for data acquisition and understanding (exploratory analysis)

You can add detailed description in this markdown related to your specific data science project.

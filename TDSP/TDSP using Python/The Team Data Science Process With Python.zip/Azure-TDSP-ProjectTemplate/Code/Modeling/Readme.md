# This folder contains code for modeling and related activities (such as feature engineering, model evaluation etc.)

You can add detailed description in this markdown related to your specific data science project.

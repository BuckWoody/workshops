<img style="float: right;" src="./assets/solutions-microsoft-logo-small.png">

## The Team Data Science Process Workshop
## https://aka.ms/tdspnotebook
### From the Microsoft Cloud and AI Team

  - To use this notebook from this location, Sign in, and then click the *Clone* button above to add it in to your own (Free) Notebook Server. The "Student Notebook" is for the students to use, and does not contain the answers to the labs. The "Instructor Notebook" is for the teacher to use with the RISE presentation tool.
  
  - New to Azure Notebooks? More here: [https://notebooks.azure.com/help/libraries](https://notebooks.azure.com/help/libraries)
  
  - [The Microsoft AI Landscape is here](https://blogs.msdn.microsoft.com/buckwoody/2018/03/27/introduction-to-the-microsoft-ai-platform/)

The Team Data Science Process (TDSP) is an agile, iterative data science methodology to deliver predictive analytics solutions and intelligent applications efficiently. TDSP helps improve team collaboration and learning. It contains a distillation of the best practices and structures from Microsoft and others in the industry that facilitate the successful implementation of data science initiatives. The goal is to help companies fully realize the benefits of their analytics program.

The TDSP is comprised of the following key components:

 - A data science lifecycle definition
 
 - A standardized project structure
    Infrastructure and resources for data science projects
    Tools and utilities for project execution
    
<p><img style="float: left; margin: 0px 15px 15px 0px;" src="./assets/aml-logo.png">Note: You can follow a complete example of this process using Azure Machine Learning:</p>

  - ["Biomedical entity recognition using Team Data Science Process (TDSP) Template"](https://docs.microsoft.com/en-us/azure/machine-learning/preview/scenario-tdsp-biomedical-recognition?toc=%2Fen-us%2Fazure%2Fmachine-learning%2Fteam-data-science-process%2Ftoc.json&bc=%2Fen-us%2Fazure%2Fbread%2Ftoc.json)</p>

*This workshop guides you through a series of exercises you can use to learn to implement the TDSP in your Data Science project, using only Python in a Notebook. You can change the **Setup** and **Lab** cells in this Notebook to use another language, another platform, and with more or fewer prompts based on your audience's needs.*
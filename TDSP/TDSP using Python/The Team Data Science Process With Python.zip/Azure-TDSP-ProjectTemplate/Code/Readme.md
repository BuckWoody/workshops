# Code folder for hosting code for a Data Science Project

This folder hosts all code for a data science project. It has three sub-folders, belonging to 3 stages of the Data Science Lifecycle:

1. Data_Acquisition_and_Understanding
2. Modeling
3. Deployment
